# 银河号表演机器人

`yinhe_robot.py` 实现以下闭环：静默监听 → Silero VAD → sherpa-onnx 流式 ASR → 指令匹配 → FSM → 音频/串口动作包，流程结束自动回到静默监听。

## 现场只需改的位置

所有口令、ASR 易错写法、音频和动作文件名都在 `speech_train.json`。音频放入 `resources/audio/` 后修改相应 `file`、`music` 字段。动作文件存放在主控板，树莓派仅把 `action` 字段中的文件名（例如 `dongzuo1.odr`）封装后发给主控，不需要、也不会在树莓派查找该文件。动作文件名统一使用 `.odr`。

灯光、风扇、旁白等需要接入现场控制器的步骤以 `note` 保留在每一流程中，避免在无明确串口协议时误发控制包；拿到协议后在 `PerformanceFSM._run_step()` 增加对应步骤即可。

## 安装与运行

1. 首次联网安装可运行 `bash install_offline_runtime.sh`。它创建 `.venv`、安装依赖，并将中文流式 ASR 与 Silero VAD 模型放到程序读取的位置；安装完成后识别无需联网。
2. 将现有机器人 SDK 中的 `datapackage.py` 放到本目录（它提供 `DataPackageConverter`）。串口、音频与动作发送直接采用原版 `action_neo.py`：`mplayer -volume 100` 播放；动作包经 `DataPackageConverter(文件).hex_output` 转换，`send_serial_data()` 发送后等待原版的 `...18`/`...19` 回包或 10 秒超时。
3. 演练配置而不接硬件：`.venv/bin/python yinhe_robot.py --dry-run --text "银河银河"`。
4. 现场运行：`.venv/bin/python yinhe_robot.py`。

## 两个终端查看状态

主终端运行 `.venv/bin/python yinhe_robot.py`，只显示流程执行、音频播放、动作包发送与主控回包。另开一个终端执行 `tail -f logs/listener.log`，单独查看静默监听、麦克风和 ASR 识别结果。执行日志同时保存在 `logs/execution.log`；ALSA/PortAudio 的底层诊断写入 `logs/listener-alsa.log`。

独立训练同一 ASR/解析链路：`.venv/bin/python speech_train.py`。程序会先列出 11 条目标指令，选中后才开始录音；每次识别结果都要确认才会追加到该指令的 `phrases`。麦克风采集直接沿用 `landundun` 的 PyAudio + `snowboy_mic` 方式。文本联调可用：`.venv/bin/python speech_train.py --text "检测机体状态"`。
