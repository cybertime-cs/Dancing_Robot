#!/usr/bin/env python3
"""银河号表演机器人主程序。

静默监听 -> Silero VAD -> sherpa-onnx 流式 ASR -> 指令匹配 -> 流程 FSM。
所有现场资源名称和可说的指令均在 speech_train.json 中维护。
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import json
import logging
import os
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import serial
except ImportError:
    serial = None

try:
    import sherpa_onnx
except ImportError:
    sherpa_onnx = None

try:
    from datapackage import DataPackageConverter
except ImportError:
    DataPackageConverter = None

ROOT = Path(__file__).resolve().parent
CONFIG_FILE = ROOT / "speech_train.json"
EXEC_LOG = logging.getLogger("yinhe.execution")
LISTEN_LOG = logging.getLogger("yinhe.listener")


class MicrophoneUnavailable(RuntimeError):
    """当前系统尚未识别到可用的真实麦克风。"""


def configure_logging():
    """执行信息显示在主终端；监听信息独立写入文件供第二终端查看。"""
    log_dir = ROOT / "logs"
    log_dir.mkdir(exist_ok=True)
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")

    for logger in (EXEC_LOG, LISTEN_LOG):
        logger.setLevel(logging.INFO)
        logger.propagate = False
        logger.handlers.clear()

    execution_file = logging.FileHandler(log_dir / "execution.log", encoding="utf-8")
    execution_file.setFormatter(formatter)
    execution_console = logging.StreamHandler()
    execution_console.setFormatter(formatter)
    EXEC_LOG.addHandler(execution_file)
    EXEC_LOG.addHandler(execution_console)

    listener_file = logging.FileHandler(log_dir / "listener.log", encoding="utf-8")
    listener_file.setFormatter(formatter)
    LISTEN_LOG.addHandler(listener_file)


@contextmanager
def redirect_native_stderr(filename: Path):
    """将 ALSA/PortAudio 的 C 层诊断写入监听日志，避免污染执行终端。"""
    filename.parent.mkdir(exist_ok=True)
    saved_stderr = os.dup(2)
    target = os.open(str(filename), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o664)
    try:
        os.dup2(target, 2)
        yield
    finally:
        os.dup2(saved_stderr, 2)
        os.close(target)
        os.close(saved_stderr)


def initialize_serial():
    """严格保留原版 action_neo.py 的串口初始化逻辑。"""
    try:
        ser = serial.Serial('/dev/ttyAMA0', 115200)
        if not ser.isOpen():
            ser.open()
        return ser
    except serial.SerialException as exc:
        EXEC_LOG.error("串口初始化失败：%s", exc)
        print(f"Error:{exc}")
        raise Exception("Failed to initialize serial connection.")


def send_serial_data(ser, data):
    """严格保留原版 action_neo.py 的动作包发送及回包等待逻辑。"""
    ser.write(bytearray(data))
    start_time = time.time()
    timeout = 10
    buffer = b''

    while True:
        if time.time() - start_time > timeout:
            print("串口通信超时，自动退出循环")
            break

        size = ser.inWaiting()
        if size > 0:
            try:
                buffer += ser.read(size)
            except Exception as exc:
                print(f"Error:{exc}")
            if b'\xff\x00\x05\x05\x00\x00\x18' in buffer or b'\xff\x00\x05\x05\x00\x00\x19' in buffer:
                print("Sucess")
                print("Buffer:", buffer)
                ser.flushInput()
                break
            time.sleep(0.5)


@dataclass
class Hardware:
    """音频与串口动作执行器；串口仅在首次动作时打开。"""

    dry_run: bool = False
    _serial: Any = None

    def get_serial(self):
        if self.dry_run:
            return None
        if self._serial is None or not self._serial.is_open:
            if serial is None:
                raise RuntimeError("缺少 pyserial：请安装 requirements.txt")
            self._serial = initialize_serial()
            EXEC_LOG.info("串口初始化成功：/dev/ttyAMA0")
        return self._serial

    def close(self):
        if self._serial is not None and self._serial.is_open:
            self._serial.close()
        self._serial = None

    def play_audio(self, filename: str, wait: bool = True) -> threading.Thread | None:
        """严格保留原版 action_neo.py 的 mplayer 播放方式。"""
        path = ROOT / filename
        if not path.exists():
            EXEC_LOG.warning("音频文件不存在（请在配置中替换）：%s", path)
            return None
        if self.dry_run:
            EXEC_LOG.info("[演练] 播放音频：%s", filename)
            return None

        def run():
            EXEC_LOG.info("开始播放音频：%s", filename)
            try:
                status = os.system('mplayer -volume 100 %s' % filename)
                if status != 0:
                    EXEC_LOG.error("音频播放命令失败（状态 %s）：%s", status, filename)
                else:
                    EXEC_LOG.info("音频播放结束：%s", filename)
            except OSError as exc:
                EXEC_LOG.error("无法播放 %s：%s", filename, exc)

        if wait:
            run()
            return None
        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        return thread

    def send_action(self, filename: str):
        """发送主控板内置动作文件名；树莓派不保存、不读取动作文件。"""
        if self.dry_run:
            EXEC_LOG.info("[演练] 发送动作：%s", filename)
            return
        if DataPackageConverter is None:
            raise RuntimeError("找不到 datapackage.DataPackageConverter，请复制机器人 SDK 到本目录/PYTHONPATH")
        try:
            EXEC_LOG.info("准备发送主控动作文件：%s", filename)
            movements = DataPackageConverter(filename).hex_output
            ser = self.get_serial()
            EXEC_LOG.info("动作包已写入串口，等待主控回包：%s", filename)
            send_serial_data(ser, movements)
            EXEC_LOG.info("主控动作流程已返回：%s", filename)
            return True
        except Exception as exc:
            # 树莓派单机演练时没有串口也要完整播放剧情；现场接上主控后会正常发送。
            EXEC_LOG.error("动作包未发送：%s；跳过动作并继续后续音频。原因：%s", filename, exc)
            self.close()
            return False


class CommandParser:
    def __init__(self, config: dict[str, Any]):
        self.commands = config["commands"]

    @staticmethod
    def clean(text: str) -> str:
        return "".join(text.lower().split()).replace("，", "").replace("。", "").replace("！", "")

    def match(self, text: str) -> tuple[str | None, dict[str, Any] | None]:
        normalized = self.clean(text)
        candidates: list[tuple[tuple[bool, int], str, dict[str, Any]]] = []
        for command_id, command in self.commands.items():
            for phrase in command["phrases"]:
                phrase = self.clean(phrase)
                if phrase and phrase in normalized:
                    # 完全匹配优先；其余情况仍采用包含式匹配，例如“出发”。
                    candidates.append(((normalized == phrase, len(phrase)), command_id, command))
        if not candidates:
            return None, None
        best_score = max(item[0] for item in candidates)
        best = [item for item in candidates if item[0] == best_score]
        # 同一强度的短口令对应多个流程时，不执行任何流程以避免误触发。
        if len({item[1] for item in best}) > 1:
            EXEC_LOG.warning("指令匹配冲突：%s", text)
            return None, None
        _, command_id, command = best[0]
        return command_id, command


class PerformanceFSM:
    IDLE = "IDLE"
    EXECUTING = "EXECUTING"

    def __init__(self, config: dict[str, Any], hardware: Hardware):
        self.config = config
        self.parser = CommandParser(config)
        self.hardware = hardware
        self.state = self.IDLE

    def handle_text(self, text: str) -> bool:
        command_id, command = self.parser.match(text)
        if command is None:
            EXEC_LOG.info("未匹配指令：%s", text)
            return False
        EXEC_LOG.info("识别指令：%s -> %s", text, command_id)
        self.run(command_id, command)
        return True

    def run(self, command_id: str, command: dict[str, Any]):
        if self.state != self.IDLE:
            EXEC_LOG.warning("机器人忙碌中，忽略：%s", command_id)
            return
        self.state = self.EXECUTING
        try:
            for step in command.get("steps", []):
                self._run_step(step)
        except Exception:
            EXEC_LOG.exception("流程 %s 执行失败", command_id)
        finally:
            self.state = self.IDLE
            EXEC_LOG.info("流程 %s 完成，回到静默监听", command_id)

    def _run_step(self, step: dict[str, Any]):
        kind = step["type"]
        EXEC_LOG.info("开始步骤：%s", kind)
        if kind == "audio":
            self.hardware.play_audio(step["file"], wait=True)
        elif kind == "action":
            self.hardware.send_action(step["file"])
        elif kind == "show":
            # 音乐与动作同时开始；动作时长结束后再进入下一剧情。
            music = self.hardware.play_audio(step["music"], wait=False) if step.get("music") else None
            self.hardware.send_action(step["action"])
            if music:
                music.join()
                EXEC_LOG.info("动作音乐已结束：%s", step["music"])
            if step.get("after_audio"):
                EXEC_LOG.info("播放动作后的语音：%s", step["after_audio"])
                self.hardware.play_audio(step["after_audio"], wait=True)
        elif kind == "wait":
            time.sleep(float(step["seconds"]))
        elif kind == "note":
            EXEC_LOG.info("现场功能提示：%s", step["text"])
        else:
            raise ValueError(f"未知步骤类型：{kind}")


class SherpaStreamingRecognizer:
    """Silero VAD + sherpa-onnx OnlineRecognizer 的单句识别封装。"""

    def __init__(self, asr_config: dict[str, Any]):
        if sherpa_onnx is None:
            raise RuntimeError("缺少 sherpa-onnx：请安装 requirements.txt")
        model_dir = ROOT / asr_config["model_dir"]
        self.sample_rate = int(asr_config.get("sample_rate", 16000))
        self.device = asr_config.get("input_device")
        self.recognizer = sherpa_onnx.OnlineRecognizer.from_transducer(
            tokens=str(model_dir / asr_config["tokens"]),
            encoder=str(model_dir / asr_config["encoder"]),
            decoder=str(model_dir / asr_config["decoder"]),
            joiner=str(model_dir / asr_config["joiner"]),
            num_threads=int(asr_config.get("num_threads", 2)),
            sample_rate=self.sample_rate,
            feature_dim=80,
            decoding_method="greedy_search",
        )
        vad_model = ROOT / asr_config["vad_model"]
        # 采用官方 Python 示例的逐项配置写法，兼容当前 sherpa-onnx 绑定。
        vad_config = sherpa_onnx.VadModelConfig()
        vad_config.silero_vad.model = str(vad_model)
        vad_config.silero_vad.threshold = float(asr_config.get("vad_threshold", 0.25))
        vad_config.silero_vad.min_silence_duration = float(asr_config.get("vad_min_silence", 0.5))
        vad_config.silero_vad.min_speech_duration = float(asr_config.get("vad_min_speech", 0.3))
        vad_config.silero_vad.max_speech_duration = float(asr_config.get("vad_max_speech", 10))
        vad_config.sample_rate = self.sample_rate
        vad_config.num_threads = int(asr_config.get("num_threads", 2))
        self.vad = sherpa_onnx.VoiceActivityDetector(vad_config, buffer_size_in_seconds=30)

    @staticmethod
    def _input_candidates(audio, name="snowboy_mic"):
        """返回可尝试的真实输入设备，优先指定名称但不信任虚假通道信息。"""
        inputs = []
        preferred = []
        for index in range(audio.get_device_count()):
            info = audio.get_device_info_by_index(index)
            # 设备名相同不代表它真能录音；必须先有至少一个输入通道。
            if int(info.get("maxInputChannels", 0)) < 1:
                continue
            item = (index, info)
            inputs.append(item)
            if info["name"].strip() == name:
                preferred.append(item)

        # 过滤 PortAudio 公开的虚拟 PCM，避免再尝试无服务的 PulseAudio。
        virtual = (
            "pulse", "default", "sysdefault", "front", "rear", "surround",
            "iec958", "spdif", "hdmi", "dmix", "dsnoop", "jack", "oss",
            "upmix", "vdownmix", "a52", "usb stream",
        )
        physical = [
            item for item in inputs
            if not any(word in item[1]["name"].lower() for word in virtual)
        ]
        if preferred:
            # 指定设备优先，但若打开失败，listen_once 会继续尝试下面的真实设备。
            return preferred + [item for item in physical if item not in preferred]
        if physical:
            LISTEN_LOG.info("未找到 %s，自动使用麦克风：%s", name, physical[0][1]["name"])
            return physical
        available = ", ".join(info["name"] for _, info in inputs) or "无"
        raise MicrophoneUnavailable(f"未识别到真实麦克风（当前输入：{available}）")

    @staticmethod
    def _resample(samples, source_rate: int, target_rate: int, np):
        if source_rate == target_rate:
            return samples
        target_size = max(1, round(len(samples) * target_rate / source_rate))
        return np.interp(
            np.linspace(0, len(samples) - 1, target_size),
            np.arange(len(samples)),
            samples,
        ).astype(np.float32)

    def listen_once(self, max_seconds: float = 10) -> str:
        """仅在 VAD 检测到完整语句后送入流式 ASR，返回最终文本。"""
        # 直接使用 landundun 已验证的 PyAudio + snowboy_mic 采集方式；
        # 仅将 ASR 从 Vosk 换为本项目要求的 sherpa-onnx。
        try:
            import numpy as np
            import pyaudio
        except ImportError as exc:
            raise RuntimeError("缺少 PyAudio 或 numpy：请安装 requirements.txt") from exc
        stream = self.recognizer.create_stream()
        started = time.monotonic()
        native_log = ROOT / "logs" / "listener-alsa.log"
        with redirect_native_stderr(native_log):
            audio = pyaudio.PyAudio()
        mic = None
        try:
            frames_per_buffer = 2000
            open_errors = []
            source_rate = 0
            for device_index, device_info in self._input_candidates(audio, self.device or "snowboy_mic"):
                source_rate = int(round(device_info["defaultSampleRate"]))
                try:
                    with redirect_native_stderr(native_log):
                        mic = audio.open(
                            format=pyaudio.paInt16,
                            channels=1,
                            rate=source_rate,
                            input=True,
                            input_device_index=device_index,
                            frames_per_buffer=frames_per_buffer,
                        )
                    LISTEN_LOG.info(
                        "使用录音设备：%s（%d Hz，转换为 16000 Hz）",
                        device_info["name"], source_rate,
                    )
                    break
                except OSError as exc:
                    open_errors.append(f"{device_info['name']}：{exc}")
                    LISTEN_LOG.warning("无法打开录音设备 %s，尝试下一设备：%s", device_info["name"], exc)

            if mic is None:
                detail = "；".join(open_errors) or "没有可尝试的输入设备"
                raise MicrophoneUnavailable(f"所有录音设备均无法打开：{detail}")
            vad_buffer = np.empty(0, dtype=np.float32)
            while time.monotonic() - started < max_seconds:
                raw_audio = mic.read(frames_per_buffer, exception_on_overflow=False)
                samples = np.frombuffer(raw_audio, dtype=np.int16).astype(np.float32) / 32768.0
                samples = self._resample(samples, source_rate, self.sample_rate, np)
                vad_buffer = np.concatenate((vad_buffer, samples))
                while len(vad_buffer) >= 512:
                    self.vad.accept_waveform(vad_buffer[:512])
                    vad_buffer = vad_buffer[512:]
                while not self.vad.empty():
                    segment = self.vad.front.samples
                    self.vad.pop()
                    stream.accept_waveform(self.sample_rate, segment)
                    # VAD 已给出一句完整语音，补少量静音让流式识别器输出最终结果。
                    stream.accept_waveform(self.sample_rate, [0.0] * int(0.3 * self.sample_rate))
                    stream.input_finished()
                    while self.recognizer.is_ready(stream):
                        self.recognizer.decode_stream(stream)
                    get_result = getattr(self.recognizer, "get_result_all", self.recognizer.get_result)
                    text = get_result(stream).text.strip()
                    if text:
                        return text
        finally:
            if mic is not None:
                with redirect_native_stderr(native_log):
                    mic.close()
            with redirect_native_stderr(native_log):
                audio.terminate()
        return ""


def load_config() -> dict[str, Any]:
    with CONFIG_FILE.open(encoding="utf-8") as file:
        return json.load(file)


def main() -> int:
    cli = argparse.ArgumentParser(description="银河号表演机器人")
    cli.add_argument("--dry-run", action="store_true", help="不播放、不发送串口包，只打印流程")
    cli.add_argument("--text", help="绕过麦克风，直接执行这句指令（联调用）")
    args = cli.parse_args()
    config = load_config()
    hardware = Hardware(dry_run=args.dry_run, **config.get("hardware", {}))
    fsm = PerformanceFSM(config, hardware)
    try:
        if args.text:
            return 0 if fsm.handle_text(args.text) else 2
        recognizer = SherpaStreamingRecognizer(config["asr"])
        EXEC_LOG.info("机器人初始化完成，播放监听就绪提示音。")
        hardware.play_audio("resources/audio/ding.wav", wait=True)
        LISTEN_LOG.info("银河号已开机，进入静默监听阶段；按 Ctrl+C 退出。")
        while True:
            LISTEN_LOG.info("等待语音输入……")
            try:
                text = recognizer.listen_once()
            except MicrophoneUnavailable as exc:
                LISTEN_LOG.warning("%s；2 秒后重试。", exc)
                time.sleep(2)
                continue
            if text:
                LISTEN_LOG.info("ASR 识别结果：%s", text)
                fsm.handle_text(text)
            else:
                LISTEN_LOG.info("本次监听未识别到有效语音。")
    except KeyboardInterrupt:
        LISTEN_LOG.info("已停止")
    except Exception as exc:
        # 错误只记录在监听日志，避免执行终端被 traceback 刷屏。
        LISTEN_LOG.error("监听异常，主程序停止：%s", exc)
        return 1
    finally:
        hardware.close()
    return 0


if __name__ == "__main__":
    configure_logging()
    raise SystemExit(main())
